function greet(name) {
    const message = `Hello, ${name}!`;
    return message;
  }
  
  function main() {
    const result = greet('VS Code');
    console.log(result);
  }
  
  main();
  
