const message = `Hello, ${name}!`;
return message;
}

function main() {
const result = greet('VS Code');
c
function greet(name) {onsole.log(result);
}

main();