// Syntax Error Example
function greet() {
    console.log("Hello world");
// Missing closing brace is a syntax error
    
greet(); // Call the function to execute its contents