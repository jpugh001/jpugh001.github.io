let number = 5;
const greeting = "Hello, World!";
let isTrue = false;
let scores = [90, 85, 88];

console.log(number);
console.log(greeting);
console.log(isTrue);
console.log(scores);

if (number > 0) {
    console.log("Positive number");
  } else {
    console.log("Non-positive number");
  }

  for (let i = 0; i < scores.length; i++) {
    console.log(scores[i]);
  }
  