let number = 5;
const greeting = "Hello, World!";
let isTrue = false;
let scores = [90, 85, 88];

console.log(number);
console.log(greeting);
console.log(isTrue);
console.log(scores);
